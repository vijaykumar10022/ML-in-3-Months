pi = 3.14
def cube(x):
    return x**3
def square(x):
    return x**2